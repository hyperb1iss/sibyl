# SurrealDB Helm Chart

![Version: 0.5.0](https://img.shields.io/badge/Version-0.5.0-informational?style=for-the-badge) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=for-the-badge) ![AppVersion: 2.6.5](https://img.shields.io/badge/AppVersion-2.6.5-informational?style=for-the-badge)

SurrealDB is the ultimate cloud database for tomorrow's applications.

## Introduction

This chart facilitates the deployment of [SurrealDB](https://surrealdb.com/docs/surrealdb/) on Kubernetes clusters.

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| surrealdb |  | <https://github.com/surrealdb> |

## Usage

Read the Kubernetes Deployment guides in https://surrealdb.com/docs/deployment

## SurrealDB versions

The chart default `appVersion` tracks the latest SurrealDB **2.x** release. SurrealDB 3.x is supported by setting `image.tag` (for example `v3.2.0`). The 2.x and 3.x on-disk formats are incompatible, so do not upgrade an existing PersistentVolume by only changing the image tag. Follow the official [2.x to 3.x migration guide](https://surrealdb.com/docs/build/migrating/from-old-surrealdb-versions/2x-to-3x).

A chart **minor** version bump means either a new chart feature or a SurrealDB minor bump in `appVersion` (the default image when `image.tag` is empty). Pinning `image.tag` is highly recommended so chart upgrades do not change the SurrealDB image unexpectedly.

## Overrides

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| fullnameOverride | string | `""` | String to fully override `"surrealdb"` |
| nameOverride | string | `""` | Provide a name in place of `surrealdb` |

## General parameters

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Assign custom [affinity] rules to the deployment |
| args | list | `["start"]` | Command line arguments to pass to SurrealDB |
| extraContainers | list | `[]` | for deploying of additional Containers |
| horizontalPodAutoscaler.enabled | bool | `false` | Enable the horizontal pod autoscaler for Surrealdb pods |
| horizontalPodAutoscaler.maxReplicas | int | `1` | Max pod replicas |
| horizontalPodAutoscaler.metrics | list | `[]` (See [values.yaml]) | Metrics which the autoscaler reacts to. See [kubernetes autoscale docs](https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/) for metric format. |
| horizontalPodAutoscaler.minReplicas | int | `1` | Min pod replicas |
| initContainers | list | `[]` | initContainers |
| lifecycle | object | `{}` | Container lifecycle hooks (e.g. preStop / postStart). Optional; unset by default. The default surrealdb/surrealdb image has no shell, so exec hooks that invoke /bin/sh or sleep will fail unless you use a custom image that includes them. With the default image, prefer raising terminationGracePeriodSeconds so the kubelet gives the process more time to exit cleanly after SIGTERM (including RocksDB backends that may still be flushing). Sleep in a preStop hook only delays SIGTERM; it does not flush or compact RocksDB by itself. Example (requires an image with a shell):   lifecycle:     preStop:       exec:         command: ["/bin/sh", "-c", "sleep 60"] |
| livenessProbe | object | See [values.yaml] | Configure liveness probe |
| nodeSelector | object | `{}` | [Node selector] |
| podAnnotations | object | `{}` | Annotations to be added to SurrealDB pods |
| podExtraEnv | list | `[]` | Extra env entries added to the SurrealDB pods |
| podSecurityContext | object | `{}` (See [values.yaml]) | Toggle and define pod-level security context. |
| readinessProbe | object | See [values.yaml] | Configure readiness probe |
| replicaCount | int | `1` | The number of SurrealDB pods to run  Note that you usually scale this only when the backend supports it. For example, if you specify volumes and volumeMounts to make this SurrealDB instance stateful, you should not scale it, as it will result in two or more instances writing to the same volume or working independently. |
| resources | object | `{}` | Resource limits and requests |
| securityContext | object | `{}` (See [values.yaml]) | SurrealDB container-level security context |
| strategy | object | `{"type":"RollingUpdate"}` | Set to `{"type":"Recreate"}` when the deployment has an RWO PV attached and replicas = 1. Otherwise, an update can get stuck, as the previous pod remains attached to the PV, and the "incoming" pod can never start. Changing the strategy to "Recreate" will terminate the single previous pod, so that the new, incoming pod can attach to the PV |
| terminationGracePeriodSeconds | string | unset (kubelet default of 30s) | Pod termination grace period in seconds (overrides the kubelet default of 30s). Raising this is the practical knob for graceful shutdown with the default image. Leave unset to use the kubelet default. Example: `terminationGracePeriodSeconds: 300` |
| tolerations | list | `[]` | [Tolerations] for use with node taints |
| volumeMounts | list | `[]` | Additional volume mounts for SurrealDB container |
| volumes | list | `[]` | Additional volumes for SurrealDB pod |

## SurrealDB parameters

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| surrealdb.log | string | `"info"` | Log configuration |
| surrealdb.path | string | `"memory"` | path: tikv://tikv-pd:2379 |
| surrealdb.port | int | `8000` | SurrealDB container port |

## Image parameters

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy for SurrealDB |
| image.repository | string | `"surrealdb/surrealdb"` | Repository to use for SurrealDB |
| image.tag | string | `""` (defaults to chart appVersion) | Tag to use for SurrealDB |
| imagePullSecrets | list | `[]` | Secrets with credentials to pull images from a private registry |

## Service parameters

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| service.annotations | object | `{}` | Service annotations |
| service.port | int | `8000` | Service port |
| service.targetPort | string | `"http"` | Target container port |
| service.type | string | `"ClusterIP"` | Service type |

## Service account parameters

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| serviceAccount.create | bool | `true` | Specifies whether a service account should be created |
| serviceAccount.name | string | `""` (defaults to the fullname template) | The name of the service account to use. |

## Horizontal Pod Autoscaler parameters

An optional horizontal pod autoscaler that, when defined, will use metrics to scale Surrealdb pods. Note that the replicaCount variable will be ignored when the horizontal pod autoscaler is used and is replaced by the minReplicas and maxReplicas defined here. The HPA can be added or removed at anytime using `helm upgrade`.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| horizontalPodAutoscaler.enabled | bool | `false` | Enable the horizontal pod autoscaler for Surrealdb pods |
| horizontalPodAutoscaler.maxReplicas | int | `1` | Max pod replicas |
| horizontalPodAutoscaler.metrics | list | `[]` (See [values.yaml]) | Metrics which the autoscaler reacts to. See [kubernetes autoscale docs](https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale-walkthrough/) for metric format. |
| horizontalPodAutoscaler.minReplicas | int | `1` | Min pod replicas |

## Ingress parameters

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| ingress.annotations | object | `{}` | Additional ingress annotations |
| ingress.className | string | `""` | Defines which ingress controller will implement the resource |
| ingress.defaultBackend | bool | `true` | Create default backend |
| ingress.enabled | bool | `false` | Enable an ingress resource |
| ingress.hosts | list | `[]` (See [values.yaml]) | List of hosts to be covered by ingress record |
| ingress.tls | list | `[]` (See [values.yaml]) | List of TLS configuration |

## Persistence parameters

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| persistence.accessModes | list | `["ReadWriteOnce"]` | Access modes for the PVC |
| persistence.annotations | object | `{}` | Annotations for the PVC |
| persistence.enabled | bool | `false` | Enable persistent storage |
| persistence.mountPath | string | `"/data"` | Mount path for the persistent volume |
| persistence.selector | object | `{}` (no selector) | Selector to match an existing Persistent Volume |
| persistence.size | string | `"10Gi"` | Size of the persistent volume |
| persistence.storageClassName | string | `""` (uses default storage class) | Storage class name for the PVC |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs](https://github.com/norwoodj/helm-docs)
